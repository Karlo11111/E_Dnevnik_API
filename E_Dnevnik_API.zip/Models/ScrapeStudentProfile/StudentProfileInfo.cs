﻿namespace E_Dnevnik_API.Models.ScrapeStudentProfile
{
    public class StudentProfileInfo
    {
        public string? StudentSchool { get; set; }
        public string? StudentSchoolCity { get; set; }
        public string? StudentSchoolYear { get; set; }
        public string? StudentGrade { get; set; }
        public string? StudentName { get; set; }
        public string? ClassMaster { get; set; }
        public string? StudentProgram { get; set; }
    }
}
