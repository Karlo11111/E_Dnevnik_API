﻿using E_Dnevnik_API.Models.ScrapeSubjects;
using Newtonsoft.Json;

namespace E_Dnevnik_API.Models.ScrapeStudentProfile
{
    public class StudentProfileResult
    {
        public StudentProfileInfo? StudentProfile { get; set; }
    }
}
