﻿namespace E_Dnevnik_API.Models.DifferentGradeLinks
{
    public class DifferentGradeResult
    {
        public List<DifferentGrade> DifferentGrade { get; set; } = new List<DifferentGrade>();
    }

}
