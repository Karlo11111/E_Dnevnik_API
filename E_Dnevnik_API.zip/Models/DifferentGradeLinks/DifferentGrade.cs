﻿namespace E_Dnevnik_API.Models.DifferentGradeLinks
{
    public class DifferentGrade
    {
        public string ? GradeYear { get; set; }

        public string ? GradeLink { get; set; }
    }
}
