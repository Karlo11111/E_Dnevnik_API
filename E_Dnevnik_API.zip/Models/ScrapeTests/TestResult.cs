﻿namespace E_Dnevnik_API.Models.ScrapeTests
{
    public class TestResult
    {
        public List<TestInfo>? Tests { get; set; }
    }
}
