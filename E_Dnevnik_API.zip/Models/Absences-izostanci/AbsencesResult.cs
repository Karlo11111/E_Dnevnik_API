﻿namespace E_Dnevnik_API.Models.Absences_izostanci
{
    public class AbsencesResult
    {
        public AbsanceRecord[]? Absences { get; set; }
    }
}
