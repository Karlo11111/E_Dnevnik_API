﻿namespace E_Dnevnik_API.Models.Absences_izostanci
{
    public class AbsanceRecord
    {
        public string? Date { get; set; }
        public List<string>? Subjects { get; set; }
    }
}
